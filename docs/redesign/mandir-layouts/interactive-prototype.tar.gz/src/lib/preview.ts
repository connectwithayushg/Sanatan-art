import { PREVIEW_PREFIX } from './storage'

export const PREVIEW_LAYOUT = new URLSearchParams(location.search).get('layout') === '2' ? '2' : '1'
document.documentElement.dataset.previewLayout = PREVIEW_LAYOUT
const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date())
const part = (name: string) => parts.find(p => p.type === name)!.value
const today = `${part('year')}-${part('month')}-${part('day')}`
const seed = () => {
  if (!localStorage.getItem(PREVIEW_PREFIX + 'lastDeity')) localStorage.setItem(PREVIEW_PREFIX + 'lastDeity', JSON.stringify('shiv'))
  localStorage.setItem(PREVIEW_PREFIX + 'dvarDay', JSON.stringify(`${part('year')}-${Number(part('month'))}-${Number(part('day'))}`))
  localStorage.setItem(PREVIEW_PREFIX + 'dailyOpenerDay', JSON.stringify(today))
}
seed()
addEventListener('message', event => {
  if (event.origin !== 'http://127.0.0.1:8789') return
  if (event.data?.type === 'sanatan-preview-reset') {
    for (const key of Object.keys(localStorage)) if (key.startsWith(PREVIEW_PREFIX)) localStorage.removeItem(key)
    seed()
    location.hash = '#mandir/shiv'
    location.reload()
  }
  if (event.data?.type === 'sanatan-preview-light') (document.querySelector('.photo-offering-diya') as HTMLButtonElement | null)?.click()
})
