export const PREVIEW_PREFIX = 'sanatan-preview-' + (new URLSearchParams(location.search).get('layout') === '2' ? '2' : '1') + ':'

/** Tiny localStorage wrapper that never throws (private mode, blocked storage). */
export function load<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(PREVIEW_PREFIX + key)
    return v === null ? fallback : (JSON.parse(v) as T)
  } catch {
    return fallback
  }
}

export function save<T>(key: string, value: T) {
  try {
    localStorage.setItem(PREVIEW_PREFIX + key, JSON.stringify(value))
  } catch {
    /* storage unavailable */
  }
}
