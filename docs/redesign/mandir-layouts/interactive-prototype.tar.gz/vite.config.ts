import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  cacheDir: '.vite-cache',
  publicDir: '/Users/falcon/Documents/ChatGPT/SanatanGpt/public',
  server: { host: '127.0.0.1', port: 5175, strictPort: true, fs: { allow: ['/Users/falcon/Documents/ChatGPT/SanatanGpt', '/Users/falcon/Downloads/Sanatan/mockups-2026-10-28/interactive'] } },
  plugins: [react(), tailwindcss()],
})
