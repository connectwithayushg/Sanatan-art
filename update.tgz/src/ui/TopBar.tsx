import { useTranslation } from 'react-i18next'
import { save } from '../lib/storage'
import { SearchGlyph } from '../features/search/Search'

const BIG = 1.25

/** Brand on the left (tapping it goes home); search, text size and language on the right, the same on every page. */
export function TopBar({ scale, setScale, onSearch, onHome, band = false }: { scale: number; setScale: (s: number) => void; onSearch: () => void; onHome: () => void; band?: boolean }) {
  const { t, i18n } = useTranslation()
  const big = scale >= BIG
  const toggleLang = () => {
    const next = i18n.language === 'hi' ? 'en' : 'hi'
    void i18n.changeLanguage(next)
    save('lang', next)
  }
  // Fixed pixel sizes so the bar never overflows when the text is enlarged.
  const ring = band ? 'border-white/45 bg-white/15 text-white' : 'border-black/10 bg-white text-[#2b1a10]'
  const round = `grid h-11 w-11 shrink-0 place-items-center rounded-full border-[1.5px] ${ring} transition active:scale-95`

  return (
    <header className={`relative z-10 ${band ? 'bg-[#d9600b]' : ''}`}>
      <div className="mx-auto flex h-[60px] max-w-xl items-center gap-2 px-4">
        <button onClick={onHome} aria-label={t('nav_aaj')} className={`min-w-0 truncate font-display text-[26px] leading-none ${band ? 'text-white' : 'text-[#c24e06]'}`}>
          {t('brand')}
        </button>
        <div className="ml-auto flex items-center gap-2">
          <button className={round} onClick={onSearch} aria-label={t('searchTitle')}>
            <SearchGlyph size={21} />
          </button>
          <button className={`${round} text-[17px] font-bold`} aria-pressed={big} aria-label={big ? t('smallerText') : t('biggerText')} onClick={() => setScale(big ? 1 : BIG)}>
            {i18n.language === 'hi' ? (big ? 'अ−' : 'अ+') : big ? 'A−' : 'A+'}
          </button>
          <button className={`h-11 shrink-0 rounded-full border-[1.5px] ${ring} px-4 text-[16px] font-semibold transition active:scale-95`} onClick={toggleLang} lang={i18n.language === 'hi' ? 'en' : 'hi'}>
            {t('lang')}
          </button>
        </div>
      </div>
    </header>
  )
}
