import { useEffect, useState } from 'react'

/** Where the deity actually is inside a cut-out picture, as fractions of the picture, plus its width/height ratio. */
export interface CutBox {
  l: number
  t: number
  r: number
  b: number
  a: number
}

const cache = new Map<string, CutBox>()

/** Finds the visible part of a transparent cut-out (ignoring stray specks) so the Mandir can size and centre every deity the same way. */
export function useCutBox(src: string): CutBox | null {
  const [box, setBox] = useState<CutBox | null>(() => cache.get(src) ?? null)
  useEffect(() => {
    const hit = cache.get(src)
    if (hit) {
      setBox(hit)
      return
    }
    setBox(null)
    let gone = false
    const img = new Image()
    img.onload = () => {
      if (gone) return
      const a = img.naturalWidth / img.naturalHeight
      const w = 96
      const h = Math.max(1, Math.round(w / a))
      const found: CutBox = { l: 0, t: 0, r: 1, b: 1, a }
      try {
        const c = document.createElement('canvas')
        c.width = w
        c.height = h
        const ctx = c.getContext('2d', { willReadFrequently: true })!
        ctx.drawImage(img, 0, 0, w, h)
        const px = ctx.getImageData(0, 0, w, h).data
        const rows = new Array<number>(h).fill(0)
        const cols = new Array<number>(w).fill(0)
        for (let y = 0; y < h; y++)
          for (let x = 0; x < w; x++)
            if (px[(y * w + x) * 4 + 3] > 40) {
              rows[y]++
              cols[x]++
            }
        const first = (v: number[]) => v.findIndex((n) => n >= 2)
        const last = (v: number[]) => v.length - 1 - [...v].reverse().findIndex((n) => n >= 2)
        const t = first(rows)
        const l = first(cols)
        if (t >= 0 && l >= 0) {
          found.t = t / h
          found.b = (last(rows) + 1) / h
          found.l = l / w
          found.r = (last(cols) + 1) / w
        }
      } catch {
        /* keep the whole picture */
      }
      cache.set(src, found)
      setBox(found)
    }
    img.onerror = () => {
      if (!gone) setBox({ l: 0, t: 0, r: 1, b: 1, a: 6 / 7 })
    }
    img.src = src
    return () => {
      gone = true
    }
  }, [src])
  return box
}
