import { useTranslation } from 'react-i18next'
import { AARTIS } from '../../content/aartis'
import { AartiView, PORTRAIT } from '../diwali/AartiView'

/** When each aarti is usually sung; weekdays are 0 = Sunday. */
const WHEN: Record<string, { hi: string; en: string; days: number[] }> = {
  ganesh: { hi: 'हर पूजा के आरंभ में, बुधवार', en: 'At the start of every puja, Wednesdays', days: [3] },
  lakshmi: { hi: 'शुक्रवार और दीवाली', en: 'Fridays and Diwali', days: [5] },
  jagdish: { hi: 'हर शाम, गुरुवार', en: 'Every evening, Thursdays', days: [4] },
  shiv: { hi: 'सोमवार और शिवरात्रि', en: 'Mondays and Shivratri', days: [1] },
  hanuman: { hi: 'मंगलवार और शनिवार', en: 'Tuesdays and Saturdays', days: [2, 6] },
  ambe: { hi: 'नवरात्रि और रविवार', en: 'Navratri and Sundays', days: [0] },
  kunjbihari: { hi: 'जन्माष्टमी और एकादशी', en: 'Janmashtami and Ekadashi', days: [] },
  ram: { hi: 'राम नवमी, दशहरा और दीवाली', en: 'Ram Navami, Dussehra and Diwali', days: [] },
  govardhan: { hi: 'गोवर्धन पूजा', en: 'Govardhan Puja', days: [] },
}

/** All aartis as a list; one opens full screen with the sing-along view. */
export function AartiLibrary({ id, open }: { id: string | null; open: (id: string) => void }) {
  const { t, i18n } = useTranslation()
  const hi = i18n.language === 'hi'
  const chosen = AARTIS.find((a) => a.id === id)
  if (chosen) return <AartiView key={chosen.id} aartis={[chosen]} onBack={() => history.back()} />

  const today = new Date().getDay()
  const isToday = (aid: string) => WHEN[aid]?.days.includes(today) ?? false
  const sorted = [...AARTIS].sort((a, b) => Number(isToday(b.id)) - Number(isToday(a.id)))

  return (
    <main className="mx-auto max-w-xl px-5 pt-4 pb-6">
      <h1 className="text-center font-display text-[2.3rem] leading-tight text-warm">{t('allAartis')}</h1>
      <p className="mt-1 text-center text-lg text-dim">{t('aartiIntro')}</p>
      <ol className="mt-6 grid gap-3">
        {sorted.map((a, i) => {
          const w = WHEN[a.id]
          const now = isToday(a.id)
          return (
            <li key={a.id} className="rise" style={{ animationDelay: `${i * 40}ms` }}>
              <button
                onClick={() => open(a.id)}
                className={`flex w-full items-center gap-4 rounded-3xl px-4 py-3 text-left ring-1 transition active:scale-[0.99] ${
                  now ? 'lamplight ring-flame' : 'bg-night2/70 ring-black/10 hover:ring-black/15'
                }`}
              >
                <img
                  src={PORTRAIT[a.id] ?? '/art/thumb/H4ilfu3vftk.jpg'}
                  alt=""
                  width={60}
                  height={80}
                  loading="lazy"
                  className="h-20 w-[3.75rem] shrink-0 rounded-t-full object-cover object-top ring-2 ring-flame/60"
                />
                <span className="min-w-0 flex-1">
                  {now && (
                    <span className="mb-1 inline-block rounded-full bg-flame/15 px-3 py-0.5 text-[0.95rem] font-semibold text-flame">{t('aartiToday')}</span>
                  )}
                  <span className="block font-display text-[1.55rem] leading-tight text-warm">{hi ? a.title_hi : a.title_en}</span>
                  {w && <span className="block text-[1rem] text-dim">{hi ? w.hi : w.en}</span>}
                </span>
                <span aria-hidden="true" className="text-3xl text-flame">›</span>
              </button>
            </li>
          )
        })}
      </ol>
    </main>
  )
}
