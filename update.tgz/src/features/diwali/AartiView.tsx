import { useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { GANESH_AARTI, LAKSHMI_AARTI, type Aarti } from '../../content/aartis'
import { useStored } from '../../lib/useStored'
import { buzz, ringGhanti } from '../../lib/audio/bell'
import { IconBell } from '../../ui/Ornaments'

export const PORTRAIT: Record<string, string> = {
  ganesh: '/art/thumb/fv3EpXA6jCA.jpg',
  lakshmi: '/art/lakshmi-1930s.jpg',
  jagdish: '/art/thumb/99DGEk5yHqg.jpg',
  shiv: '/art/thumb/JxJ15qeVisk.jpg',
  hanuman: '/art/thumb/1qvWMJv_NUU.jpg',
  ambe: '/art/thumb/vruHKfa-Fi0.jpg',
  kunjbihari: '/art/thumb/bxYwhPIFOcA.jpg',
  govardhan: '/art/thumb/-jeARsrDO1c.jpg',
  ram: '/art/deity/ram-face.webp',
}
/** Seconds the lyrics take to move up by one line: slow, normal, fast. People sing at their own pace, so they pick. */
const PACE = [6.5, 4.8, 3.4] as const
const PACE_KEYS = ['speedSlow', 'speedMid', 'speedFast'] as const

const short = (title: string) => title.replace(/^(श्री|Shri) /, '').replace(/ (जी की आरती|की आरती|Aarti)$/, '')

/**
 * Sing-along aarti. The words drift up slowly like film subtitles, a few stanzas on screen at once, so everyone can
 * read ahead or look back; the stanza at the reading line is darker. With two aartis, a switch picks between them;
 * with one, a back button returns to the library.
 */
export function AartiView({ aartis = [GANESH_AARTI, LAKSHMI_AARTI], onBack }: { aartis?: Aarti[]; onBack?: () => void }) {
  const { t, i18n } = useTranslation()
  const l = i18n.language as 'hi' | 'en'
  const AARTIS = aartis
  const [stored, setActive] = useStored('aarti', 1)
  const active = AARTIS.length > 1 ? stored : 0
  const [meaning, setMeaning] = useStored('showMeaning', false)
  const [pace, setPace] = useStored('aartiPace', 1)
  const [playing, setPlaying] = useState(false)
  const [cur, setCur] = useState(0)
  const aarti = AARTIS[active] ?? AARTIS[0]
  const box = useRef<HTMLDivElement>(null)

  // Each stanza after the first ends with the refrain, as families sing it.
  const stanzas = useMemo(() => aarti.stanzas.map((s, i) => ({ ...s, lines: i > 0 ? [...s.lines, aarti.refrain] : s.lines })), [aarti])

  // Which stanza sits on the reading line, a third of the way down the box.
  const track = () => {
    const el = box.current
    if (!el) return
    const line = el.getBoundingClientRect().top + el.clientHeight * 0.33
    const kids = [...el.querySelectorAll<HTMLElement>('[data-stanza]')]
    let c = 0
    kids.forEach((k, i) => {
      if (k.getBoundingClientRect().top <= line) c = i
    })
    setCur(c)
  }

  useEffect(() => {
    if (!playing) return
    const el = box.current
    if (!el) return
    const lineHeight = parseFloat(getComputedStyle(el.querySelector('[data-line]') ?? el).lineHeight) || 38
    const speed = lineHeight / PACE[pace] // pixels per second
    let pos = el.scrollTop
    let last = performance.now()
    let raf = 0
    const step = (now: number) => {
      // If the reader has scrolled by hand, carry on from where they left it.
      if (Math.abs(el.scrollTop - pos) > 4) pos = el.scrollTop
      pos += (speed * (now - last)) / 1000
      last = now
      el.scrollTop = pos
      if (el.scrollTop + el.clientHeight >= el.scrollHeight - 2) {
        setPlaying(false)
        ringGhanti()
        return
      }
      raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [playing, pace])

  const pick = (i: number) => {
    setActive(i)
    setPlaying(false)
    box.current?.scrollTo({ top: 0 })
  }
  const restart = () => {
    buzz(10)
    box.current?.scrollTo({ top: 0 })
    setCur(0)
  }

  return (
    <main className="mx-auto flex h-[calc(100dvh-66px-env(safe-area-inset-bottom,0px)-60px)] min-h-[32rem] max-w-xl flex-col px-4">
      <div className="mt-2 flex items-center gap-2">
        {onBack && (
          <button onClick={onBack} className="h-11 shrink-0 rounded-full border-[1.5px] border-dim/50 px-4 text-[0.95rem] font-semibold text-warm">
            ‹ {t('nav_aarti')}
          </button>
        )}
        {AARTIS.length > 1 ? (
          <div className="grid flex-1 grid-cols-2 gap-1 rounded-full bg-night2 p-1" role="tablist">
            {AARTIS.map((a, i) => (
              <button
                key={a.id}
                role="tab"
                aria-selected={i === active}
                onClick={() => pick(i)}
                className={`min-h-10 rounded-full px-2 text-[0.95rem] font-semibold leading-tight transition-colors ${
                  i === active ? 'bg-flame text-ember' : 'text-dim hover:text-warm'
                }`}
              >
                {short(l === 'hi' ? a.title_hi : a.title_en)}
              </button>
            ))}
          </div>
        ) : (
          <span className="flex-1" />
        )}
        <button
          aria-pressed={meaning}
          onClick={() => setMeaning(!meaning)}
          className={`h-11 shrink-0 rounded-full border-[1.5px] px-4 text-[0.95rem] font-semibold transition-colors ${
            meaning ? 'border-flame bg-flame text-ember' : 'border-dim/50 text-warm'
          }`}
        >
          {t('meaning')}
        </button>
      </div>

      <div className="mt-3 flex items-center gap-3">
        <img src={PORTRAIT[aarti.id] ?? '/art/thumb/H4ilfu3vftk.jpg'} alt="" width={44} height={56} className="h-14 w-11 shrink-0 rounded-t-full object-cover object-top" />
        <h1 className="font-display text-[1.45rem] leading-tight text-warm">{l === 'hi' ? aarti.title_hi : aarti.title_en}</h1>
      </div>

      <div ref={box} onScroll={track} className="lyrics-fade mt-2 min-h-0 flex-1 overflow-y-auto pt-[18%] pb-[70%]" aria-live="off">
        {stanzas.map((s, i) => (
          <section key={`${active}-${i}`} data-stanza className={`mb-6 transition-colors duration-700 ${i === cur ? 'text-warm' : 'text-warm/35'}`}>
            {s.lines.map((line, j) => (
              <p key={j} data-line className="font-scripture text-[1.35rem] font-semibold leading-[1.55]">
                {line}
              </p>
            ))}
            {meaning && <p className="mt-1.5 border-l-[3px] border-flame/30 pl-3 text-[0.9rem] leading-relaxed text-dim">{l === 'hi' ? s.meaning_hi : s.meaning_en}</p>}
          </section>
        ))}
      </div>

      <div className="grid grid-cols-[3.25rem_minmax(0,1fr)_auto_3.25rem] items-center gap-2 pb-3 pt-2">
        <button onClick={restart} aria-label={t('restart')} className="grid h-[3.25rem] place-items-center rounded-full border-[1.5px] border-black/15 text-warm active:scale-95">
          <RestartGlyph />
        </button>
        <button
          onClick={() => {
            buzz(15)
            const el = box.current
            if (!playing && el && el.scrollTop + el.clientHeight >= el.scrollHeight - 2) el.scrollTo({ top: 0 })
            setPlaying(!playing)
          }}
          className="btn btn-flame min-h-[3.25rem] min-w-0 px-2 text-[1.05rem]"
        >
          {playing ? <PauseGlyph /> : <PlayGlyph />} {playing ? t('pause') : t('play')}
        </button>
        <button
          onClick={() => setPace((pace + 1) % PACE.length)}
          aria-label={`${t('speed')}: ${t(PACE_KEYS[pace])}`}
          className="h-[3.25rem] rounded-full border-[1.5px] border-black/15 px-3 text-[0.9rem] font-semibold text-warm active:scale-95"
        >
          {t('speed')}: {t(PACE_KEYS[pace])}
        </button>
        <button
          onClick={() => {
            buzz(40)
            ringGhanti()
          }}
          aria-label={t('ringBell')}
          className="grid h-[3.25rem] place-items-center rounded-full border-[1.5px] border-flame/60 text-flame active:scale-95"
        >
          <IconBell />
        </button>
      </div>
    </main>
  )
}

function RestartGlyph() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M4 12 A8 8 0 1 0 7 5.8" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M7 2 V6.5 H11.5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function PlayGlyph() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true">
      <path d="M5 3 L17 10 L5 17Z" fill="currentColor" />
    </svg>
  )
}
function PauseGlyph() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true">
      <rect x="4" y="3" width="4.5" height="14" rx="1" fill="currentColor" />
      <rect x="11.5" y="3" width="4.5" height="14" rx="1" fill="currentColor" />
    </svg>
  )
}
