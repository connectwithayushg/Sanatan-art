/** Official YouTube uploads (T-Series Bhakti Sagar) shown above each aarti. The video plays on YouTube; nothing is copied into the app. */
export interface AartiVideo {
  yt: string
  title: string
}
export const AARTI_VIDEOS: Record<string, AartiVideo> = {
  ganesh: { yt: 'Yuex2EnsGiY', title: 'Jai Ganesh Deva · Anuradha Paudwal' },
  lakshmi: { yt: 'SyqgAt-T0iQ', title: 'Om Jai Lakshmi Mata · Anuradha Paudwal' },
  jagdish: { yt: 'NE3SWh9_vR4', title: 'ॐ जय जगदीश हरे · Anuradha Paudwal' },
  shiv: { yt: 'BhwOproElxU', title: 'ॐ जय शिव ओंकारा · Anuradha Paudwal' },
  hanuman: { yt: 'r7GJ8GoGSD8', title: 'आरती कीजै हनुमान लला की' },
  ambe: { yt: 'RY1jmTTjvhI', title: 'जय अम्बे गौरी · Anuradha Paudwal' },
  ram: { yt: 'BoOs7cBxd6k', title: 'आरती कीजै श्री रघुवर जी की · Vaishali Samant' },
  ramstuti: { yt: 'igJHuojQHeo', title: 'श्री रामचंद्र कृपालु भजमन · Suresh Wadkar' },
  kali: { yt: 'G7TiiAj9NH0', title: 'अम्बे तू है जगदम्बे काली · Narendra Chanchal' },
  khatu: { yt: 'Hgw5AtR9GfY', title: 'ॐ जय श्री श्याम हरे · Lakhbir Singh Lakkha' },
  kunjbihari: { yt: 'EMO1AT1UQf0', title: 'आरती कुंज बिहारी की · Hariharan' },
}
