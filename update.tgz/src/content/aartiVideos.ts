/** Official YouTube uploads (T-Series Bhakti Sagar) shown above each aarti. The video plays on YouTube; nothing is copied into the app. */
export interface AartiVideo {
  yt: string
  title: string
}
export const AARTI_VIDEOS: Record<string, AartiVideo> = {
  ganesh: { yt: 'Yuex2EnsGiY', title: 'Jai Ganesh Deva · Anuradha Paudwal' },
  lakshmi: { yt: 'SyqgAt-T0iQ', title: 'Om Jai Lakshmi Mata · Anuradha Paudwal' },
  jagdish: { yt: 'NE3SWh9_vR4', title: 'ॐ जय जगदीश हरे · Anuradha Paudwal' },
  shiv: { yt: 'BhwOproElxU', title: 'ॐ जय शिव ओंकारा · Anuradha Paudwal' },
  hanuman: { yt: 'r7GJ8GoGSD8', title: 'आरती कीजै हनुमान लला की' },
  ambe: { yt: 'RY1jmTTjvhI', title: 'जय अम्बे गौरी · Anuradha Paudwal' },
  kunjbihari: { yt: 'EMO1AT1UQf0', title: 'आरती कुंज बिहारी की · Hariharan' },
}
